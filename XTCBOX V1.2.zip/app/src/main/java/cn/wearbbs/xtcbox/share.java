package cn.wearbbs.xtcbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.xtc.shareapi.share.communication.BaseResponse;
import com.xtc.shareapi.share.communication.SendMessageToXTC;
import com.xtc.shareapi.share.communication.ShowMessageFromXTC;
import com.xtc.shareapi.share.interfaces.IResponseCallback;
import com.xtc.shareapi.share.manager.ShareMessageManager;
import com.xtc.shareapi.share.manager.XTCCallbackImpl;
import com.xtc.shareapi.share.shareobject.XTCAppExtendObject;
import com.xtc.shareapi.share.shareobject.XTCImageObject;
import com.xtc.shareapi.share.shareobject.XTCShareMessage;
import com.xtc.shareapi.share.shareobject.XTCTextObject;
import com.xtc.shareapi.share.sharescene.Chat;
public class share extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
    }
    public void share_1(View view){
        EditText a = findViewById(R.id.editText);
        String share_text = a.getText().toString();
        //第一步：创建XTCTextObject对象，并设置text属性为要分享的文本内容
        XTCTextObject xtcTextObject = new XTCTextObject();
        xtcTextObject.setText(share_text);

        //第二步：创建XTCShareMessage对象，并将shareObject属性设置为xtcTextObject对象
        XTCShareMessage xtcShareMessage = new XTCShareMessage();
        xtcShareMessage.setShareObject(xtcTextObject);

        //第三步：创建SendMessageToXTC.Request对象，并设置
        SendMessageToXTC.Request request = new SendMessageToXTC.Request();
        request.setMessage(xtcShareMessage);

        //第四步：创建ShareMessageManagr对象，调用sendRequestToXTC方法，传入SendMessageToXTC.Request对象和AppKey
        new ShareMessageManager(this).sendRequestToXTC(request, "");
    }
}