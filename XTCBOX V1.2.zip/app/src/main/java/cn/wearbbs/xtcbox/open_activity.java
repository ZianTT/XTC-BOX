package cn.wearbbs.xtcbox;

import android.content.ComponentName;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

public class open_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_activity);
    }
    public void onClick(View view){
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setComponent(new ComponentName("com.xtc.setting", "com.xtc.setting.module.dial.activity.DialActivity"));
        getApplicationContext().startActivity(intent);
    }
    public void onClick_2(View view){
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setComponent(new ComponentName("com.baidu.input.xtcime", "com.baidu.input.xtcime.demo.SettingActivity"));
        getApplicationContext().startActivity(intent);
        Toast toast = Toast.makeText(open_activity.this, "提示：长按“长按选择输入法”即可更换", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
        toast.show();
    }
    public void onClick_3(View view){
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setComponent(new ComponentName("com.xtc.selftest", "com.xtc.selftest.MainActivity"));
        getApplicationContext().startActivity(intent);
    }
    public void onClick_4(View view){
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setComponent(new ComponentName("com.xtc.selftest", "com.xtc.selftest.ui.NetworkSettingsActivity"));
        getApplicationContext().startActivity(intent);
    }
    public void onClick_5(View view){
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setComponent(new ComponentName("com.xtc.selftest", "com.xtc.selftest.ui.ControllerActivity"));
        getApplicationContext().startActivity(intent);
    }
    public void onClick_6(View view){
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setComponent(new ComponentName("com.xtc.selftest", "com.xtc.selftest.ui.DebugActivity"));
        getApplicationContext().startActivity(intent);
    }
}