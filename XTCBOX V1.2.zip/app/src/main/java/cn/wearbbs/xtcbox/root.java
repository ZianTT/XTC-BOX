package cn.wearbbs.xtcbox;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.DataOutputStream;
import java.io.File;
import java.util.Collections;
import java.util.List;

public class root extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root);
    }
    public static boolean is_root(){
        boolean res = false;
        try{
            if ((!new File("/system/bin/su").exists()) &&
                    (!new File("/system/xbin/su").exists())){
                res = false;
            }
            else {
                res = true;
            };
        }
        catch (Exception e) {
        }
        return res;
    }
    private void runShellCommand(String command) throws Exception {
        Runtime.getRuntime().exec(command);
    }
    public void set_dpi(View view) throws Exception {
        EditText a = findViewById(R.id.EditCommand);
        String temp = a.getText().toString();
        if(temp==null||"".equals(temp)){
            Toast toast = Toast.makeText(root.this, "请输入需要调整的DPI值！", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
            toast.show();
        }else {
            runShellCommand("su -c wm density " + temp);
            Toast toast = Toast.makeText(root.this, "执行完成", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
            toast.show();
        }

    }
    public void start_shell(View view) throws Exception {
        EditText a = findViewById(R.id.EditCommand);
        String temp = a.getText().toString();
        if(temp==null||"".equals(temp)){
            Toast toast = Toast.makeText(root.this, "请输入需要执行的Shell！", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
            toast.show();
        }else {
            runShellCommand("su -c " + temp);
            Toast toast = Toast.makeText(root.this, "执行完成", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
            toast.show();
        }

    }
    public void reset_dpi(View view) throws Exception {
        runShellCommand("su -c wm density reset");
        Toast toast = Toast.makeText(root.this, "执行完成", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
        toast.show();
    }
    public void uninstall_app(View view) throws Exception {
        EditText a = findViewById(R.id.EditCommand);
        String temp = a.getText().toString();
        if(temp==null||"".equals(temp)){
            Toast toast = Toast.makeText(root.this, "请输入需要卸载的应用包名！", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
            toast.show();
        }else {
            runShellCommand("su -c pm uninstall " + temp);
            Toast toast = Toast.makeText(root.this, "执行完成", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 100);
            toast.show();
        }

    }
}